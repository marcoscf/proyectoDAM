/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectofinal;

import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.URI;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author marcos
 */
public class tablaProyecto extends javax.swing.JFrame {

    /**
     * Creates new form tablaProyecto
     */
    public tablaProyecto() {
        initComponents();
        //Cambiar el ancho de las columnas para ver bien la URL
        jTable1.getColumnModel().getColumn(0).setPreferredWidth(140);        
        jTable1.getColumnModel().getColumn(1).setPreferredWidth(40);
        jTable1.getColumnModel().getColumn(2).setPreferredWidth(180);
        jTable1.getColumnModel().getColumn(3).setPreferredWidth(180);       
        jTable1.getColumnModel().getColumn(4).setPreferredWidth(1);
        jTable1.getColumnModel().getColumn(5).setPreferredWidth(1);
        jTable1.getColumnModel().getColumn(6).setPreferredWidth(1);
        
        /*
         Al poner el metodo mostrarHipervinculos() dentro de tablaProyecto() mostraremos
         todo el contenido de la BD en la tabla.
         */
        mostrarHipervinculos();
    }

    /**
     * Abre la ventana Insertar
     */
    public void mostrarVentanaInsertar() {
        //Al pulsar el boton Insertar se ejecutara este metodo.
        ventanaInsertar ventana = new ventanaInsertar();
        ventana.setVisible(true);

    }

    /**
     * Muestra los hipervinculos de la BD en una tabla
     */
    public void mostrarHipervinculos() {
        /*
         Este metodo muestra los hipervinculos en una tabla dentro del Frame.
         Lo primero es crear la conexion a la BD y empezar la transaccion
         */
        EntityManagerFactory emf
                = Persistence.createEntityManagerFactory("$objectdb/db/hipervinculos.odb");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        //Recoge la opcion del combobox y la pasa a tipo String
        String opcion = jComboBox1.getSelectedItem().toString();
        //Permite hacer cambios en la tabla
        DefaultTableModel temp = (DefaultTableModel) jTable1.getModel();

        Action editar = new AbstractAction() {//Editar la fila al pulsar un boton
            public void actionPerformed(ActionEvent e) {
                EntityManagerFactory emf
                        = Persistence.createEntityManagerFactory("$objectdb/db/hipervinculos.odb");
                EntityManager em = emf.createEntityManager();
                em.getTransaction().begin();
                /*
                 Obtenemos el valor de la columna hipervinculo de una fila y 
                 lo usamos para obtener el id en la BD, al ser el valor de un 
                 hipervinculo distinto a los demas.
                 Este id se usa para saber que hipervinculo actualizar en el 
                 metodo actualizarHipervinculo().
                 */
                int filaBoton = jTable1.getSelectedRow();
                Object enlace = jTable1.getValueAt(filaBoton, 0);
                Query query = em.createQuery("SELECT h.id FROM hipervinculo h "
                        + "WHERE h.hipervinculo LIKE ?1");
                query.setParameter(1, enlace);
                int id = (int) query.getSingleResult();
                em.getTransaction().commit();
                em.close();
                emf.close();
                ventanaActualizar ventana = new ventanaActualizar(id);
                ventana.setVisible(true);
            }
        };

        Action borrar = new AbstractAction() {//Borrar la fila al pulsar un boton
            public void actionPerformed(ActionEvent e) {
                int filaBoton = jTable1.getSelectedRow();
                Object enlace = jTable1.getValueAt(filaBoton, 0);
                borrarHipervinculo(enlace);
                /*
                 Despues de borrar una fila usamos el metodo mostrarHipervinculos 
                 para ver los cambios.
                 */
                mostrarHipervinculos();
            }
        };

        Action abrir = new AbstractAction() {
            /*
             Abrir hipervinculo en el navegador al pulsar un boton
             El metodo getDesktop obtiene el navegador por defecto del sistema.
             */
            public void actionPerformed(ActionEvent e) {
                int filaBoton = jTable1.getSelectedRow();
                String enlace = (String) jTable1.getValueAt(filaBoton, 0);
                try {
                    Desktop.getDesktop().browse((URI.create(enlace)));
                } catch (IOException ex) {
                    Logger.getLogger(tablaProyecto.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };
        if (opcion.equals("Todos")) {//Mostrar todos los hipervinculos.
            Query query = em.createQuery("SELECT h FROM projectofinal.hipervinculo h");
            List<hipervinculo> resultados = query.getResultList();

            temp.setRowCount(0);//dejar la tabla vacia
            for (hipervinculo h : resultados) {
                //Creamos y añadimos los botones a las columnas de la tabla
                ButtonColumn botonEnlace = new ButtonColumn(jTable1, abrir, 4);
                ButtonColumn botonEditar = new ButtonColumn(jTable1, editar, 5);
                ButtonColumn botonBorrar = new ButtonColumn(jTable1, borrar, 6);
                Object fila[] = {h.getHipervinculo(), h.getTipo(), h.getComentario(),
                    h.getValoracion(), botonEnlace, botonEditar, botonBorrar};
                temp.addRow(fila);
            }
        } else {//Mostrar los hipervinculos de un tema en particular.
            Query query = em.createQuery("SELECT h FROM hipervinculo h "
                    + "WHERE h.tipo LIKE ?1");
            query.setParameter(1, opcion);
            List<hipervinculo> resultados = query.getResultList();
            temp.setRowCount(0);
            for (hipervinculo h : resultados) {
                ButtonColumn botonEnlace = new ButtonColumn(jTable1, abrir, 4);
                ButtonColumn botonEditar = new ButtonColumn(jTable1, editar, 5);
                ButtonColumn botonBorrar = new ButtonColumn(jTable1, borrar, 6);
                Object fila[] = {h.getHipervinculo(), h.getTipo(), h.getComentario(),
                    h.getValoracion(), botonEnlace, botonEditar, botonBorrar};
                temp.addRow(fila);
            }
        }
        em.getTransaction().commit();
        em.close();
        emf.close();
    }

    /**
     * Borra un hipervinculo de la BD
     * @param hipervinculo
     */
    public void borrarHipervinculo(Object hipervinculo) {//Borrar un hipervinculo
        //Creamos la conexion a la BD y empezamos la transaccion
        EntityManagerFactory emf
                = Persistence.createEntityManagerFactory("$objectdb/db/hipervinculos.odb");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();

        Query query = em.createQuery("DELETE FROM hipervinculo h "
                + "WHERE h.hipervinculo LIKE ?1");
        query.setParameter(1, hipervinculo);
        //hacemos un commit en la transaccion y cerramos la conexion
        query.executeUpdate();
        em.getTransaction().commit();
        em.close();
        emf.close();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(300, 200));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Todos", "Bases de datos", "Programacion", "Desarrollo web", "Recursos", "S. operativos" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jLabel1.setText("Tema");

        jButton1.setText("Insertar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Hipervinculo", "Tema", "Comentario", "Valoracion", "Abrir", "Editar", "Borrar"
            }
        ));
        jTable1.setRowHeight(25);
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(25);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(10);
            jTable1.getColumnModel().getColumn(2).setPreferredWidth(100);
            jTable1.getColumnModel().getColumn(4).setPreferredWidth(1);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 889, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(270, 270, 270)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // Insertar un nuevo hipervinculo en la BD
        mostrarVentanaInsertar();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // Al cambiar el valor del combobox se recargara el contenido de la tabla
        mostrarHipervinculos();
    }//GEN-LAST:event_jComboBox1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tablaProyecto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tablaProyecto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tablaProyecto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tablaProyecto.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tablaProyecto().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectofinal;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 *
 * @author marcos
 */
@Entity
public class hipervinculo implements Serializable {

    //Creamos un identificador para la entidad
    private static final int hipervinculoID = 1;
    @Id
    @GeneratedValue

    private int id;
    private String hipervinculo;
    private String tipo;
    private String comentario;
    private String valoracion;

    /**
     *
     * @param hipervinculo
     * @param tipo
     * @param comentario
     * @param valoracion
     */
    public hipervinculo(String hipervinculo, String tipo, String comentario, String valoracion) {
        this.hipervinculo = hipervinculo;
        this.tipo = tipo;
        this.comentario = comentario;
        this.valoracion = valoracion;
    }

    /**
     *
     */
    public hipervinculo() {
    }

    /**
     *
     * @return
     */
    public String getHipervinculo() {
        return hipervinculo;
    }

    /**
     *
     * @param hipervinculo
     */
    public void setHipervinculo(String hipervinculo) {
        this.hipervinculo = hipervinculo;
    }

    /**
     *
     * @return
     */
    public String getTipo() {
        return tipo;
    }

    /**
     *
     * @param tipo
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     *
     * @return
     */
    public String getComentario() {
        return comentario;
    }

    /**
     *
     * @param comentario
     */
    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    /**
     *
     * @return
     */
    public String getValoracion() {
        return valoracion;
    }

    /**
     *
     * @param valoracion
     */
    public void setValoracion(String valoracion) {
        this.valoracion = valoracion;
    }

    /**
     *
     * @return
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }
}

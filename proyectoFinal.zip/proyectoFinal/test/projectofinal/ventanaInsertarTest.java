/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectofinal;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author marcos
 */
public class ventanaInsertarTest {

    public ventanaInsertarTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class ventanaInsertar.
     */
    @Test
    public void testMain() {
        try {
            System.out.println("El metodo main funciona");
            String[] args = null;
            tablaProyecto.main(args);
            // TODO review the generated test code and remove the default call to fail.
        } catch (Exception e) {
            fail("TEl metodo main no funciona");
        }
    }

    @Test
    public void testInsertarHipervinculo() {
        try {
            hipervinculo h1 = new hipervinculo("enlace1", "todos", "comentario", "valoracion");
            assertFalse(h1.getHipervinculo().isEmpty());
            assertFalse(h1.getTipo().isEmpty());
            System.out.println("El metodo insertarHipervinculo funciona");
        } catch (Exception e) {
            fail("El metodo insertarHipervinculo no funciona");
        }
    }
}

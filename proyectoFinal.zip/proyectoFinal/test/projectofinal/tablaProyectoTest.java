/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectofinal;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author marcos
 */
public class tablaProyectoTest {

    hipervinculo h1 = new hipervinculo("enlace1", "todos", "comentario", "valoracion");

    public tablaProyectoTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class tablaProyecto.
     */
    @Test
    public void testMain() {
        try {
            System.out.println("El metodo main funciona");
            String[] args = null;
            tablaProyecto.main(args);
            // TODO review the generated test code and remove the default call to fail.
        } catch (Exception e) {
            fail("TEl metodo main no funciona");
        }
    }

    @Test
    public void testMostrarHipervinculos() {
        try {
            //Estos campos no pueden estar vacios
            assertFalse(h1.getHipervinculo().isEmpty());
            assertFalse(h1.getTipo().isEmpty());
            System.out.println("El metodo MostrarHipervinculos funciona " + h1.getHipervinculo());

        } catch (Exception e) {
            fail("El metodo MostrarHipervinculos no funciona");
        }
    }

    @Test
    public void testBorrarHipervinculo() {
        try {
            hipervinculo h2 = null;
            assertTrue(h2 == null);
            System.out.println("Los datos se han borrado");
                       
        } catch (Exception e) {
            System.out.println("Los datos no se han borrado");
            fail("El metodo borrarHipervinculo no funciona");
        }
    }
}
